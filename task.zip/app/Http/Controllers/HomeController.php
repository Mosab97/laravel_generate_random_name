<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class HomeController extends Controller
{
    public function index()
    {
        return view('welcome');
    }


    private function fact($s)
    {
        if ($s == 0) return 1;
        else return $fact = $s * $this->fact($s - 1);
    }

    public function generate(Request $request)
    {

        $rules = [
            'word' => 'required',
        ];

        $msg = [
            'word.required' => __('The Word is Required'),
        ];

        $validator = Validator::make($request->all(), $rules, $msg);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator);
        }

        $word = $request->get('word');
        $n = strlen($word);

        $words = [];
        for ($m = 1; $m <= $this->fact($n); $m++) {
            $ken = $m - 1;
            $f = 1;
            $a = array();
            for ($iaz = 1; $iaz <= $n; $iaz++) {
                $a[$iaz] = $iaz;
                $f = $f * $iaz;
            }
            for ($iaz = 1; $iaz <= $n - 1; $iaz++) {
                $f = $f / ($n + 1 - $iaz);
                $selnum = $iaz + $ken / $f;
                $temp = $a[$selnum];
                for ($jin = $selnum; $jin >= $iaz + 1; $jin--) {
                    $a[$jin] = $a[$jin - 1];
                }
                $a[$iaz] = $temp;
                $ken = $ken % $f;
            }
            $t = 1;

            $tempWord = "";

            while ($t <= $n) {
                $tempWord .= $word[$a[$t] - 1];
                $t++;
            }

            $words [] = $tempWord;

        }



        return redirect()->back()->with('words', $words);

    }
}
