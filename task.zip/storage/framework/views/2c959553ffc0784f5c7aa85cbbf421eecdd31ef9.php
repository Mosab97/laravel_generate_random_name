<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Task</title>

    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>
<body>

<div class="container">

    <form class="form" method="post" style="margin-top: 150px" action="<?php echo e(url('/generate')); ?>">
        <!--begin::Title-->
        <?php echo csrf_field(); ?>


        <div class="form-group ">
            <input
                class="form-control h-auto py-5 px-0 border-x-0 border-top-0 rounded-0 border-bottom mb-2"
                type="text" value="pizza"
                placeholder="Enter Word" name="word"
            />

            <?php $__errorArgs = ['word'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger opacity-70" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <div class="form-group d-flex flex-wrap text-center mx-auto">
            <button type="submit"
                    class="btn btn-primary btn-pill font-weight-bolder px-8 py-4 my-3 mx-auto"><?php echo e(__('Generate')); ?>

            </button>
        </div>

    </form>

    <?php if(session('words')): ?>

        <h3>The number of words : <?php echo e(count(session('words'))); ?></h3>
        <table class="table table-bordered">

            <tbody>

            <?php ($count = 0); ?>
            <?php ($i = 1); ?>


            <?php $__currentLoopData = session('words'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $word): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($i == 1): ?>
                    <tr>
                <?php endif; ?>
                    <td width="25%"><?php echo e($word); ?></td>
                <?php if($i == 4): ?>
                    </tr>
                <?php ($i= 1); ?>
                <?php else: ?>
                    <?php ($i += 1); ?>
                <?php endif; ?>

                <?php ($count += 1); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




            </tbody>
        </table>
    <?php endif; ?>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\wamp64\www\task\resources\views/welcome.blade.php ENDPATH**/ ?>